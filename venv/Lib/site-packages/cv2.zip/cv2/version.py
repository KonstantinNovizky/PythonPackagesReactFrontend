opencv_version = "4.5.3.56"
contrib = False
headless = False
ci_build = True